﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Configuration;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Linq;
using System.Xml.XmlConfiguration;
using System.Management;
using System.Diagnostics;
using Microsoft.Win32;

namespace GenaBesheniy_Utility
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            button1.FlatStyle = FlatStyle.Flat;
            button1.FlatAppearance.BorderSize = 0;
            button1.TabStop = false;
            button1.BackColor = Color.FromArgb(225, 225, 225);

            button2.FlatStyle = FlatStyle.Flat;
            button2.FlatAppearance.BorderSize = 0;
            button2.TabStop = false;
            button2.BackColor = Color.FromArgb(225, 225, 225);

            button3.FlatStyle = FlatStyle.Flat;
            button3.FlatAppearance.BorderSize = 0;
            button3.TabStop = false;
            button3.BackColor = Color.FromArgb(225, 225, 225);

            button4.FlatStyle = FlatStyle.Flat;
            button4.FlatAppearance.BorderSize = 0;
            button4.TabStop = false;
            button4.BackColor = Color.FromArgb(225, 225, 225);

            button5.FlatStyle = FlatStyle.Flat;
            button5.FlatAppearance.BorderSize = 0;
            button5.TabStop = false;
            button5.BackColor = Color.FromArgb(225, 225, 225);

            button6.FlatStyle = FlatStyle.Flat;
            button6.FlatAppearance.BorderSize = 0;
            button6.TabStop = false;
            button6.BackColor = Color.FromArgb(225, 225, 225);

            button7.FlatStyle = FlatStyle.Flat;
            button7.FlatAppearance.BorderSize = 0;
            button7.TabStop = false;
            button7.BackColor = Color.FromArgb(225, 225, 225);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string tempPath = Path.GetTempPath();

            DirectoryInfo di = new DirectoryInfo(tempPath);

            // 2. Удаляем файлы
            foreach (FileInfo file in di.GetFiles())
            {
                try
                {
                    file.Delete();
                }
                catch (Exception)
                {
                    // Если файл занят, просто идем к следующему
                    continue;
                }
            }

            // 3. Удаляем подпапки
            foreach (DirectoryInfo dir in di.GetDirectories())
            {
                try
                {
                    dir.Delete(true);
                }
                catch (Exception)
                {
                    // Если папка занята, пропускаем её
                    continue;
                }
            }
            MessageBox.Show("Папка Temp очищена", "GenaBesheniy Utility", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // 1. Получаем путь к папке Загрузки более надежным способом
            string downloadsPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads");

            if (Directory.Exists(downloadsPath))
            {
                DirectoryInfo di = new DirectoryInfo(downloadsPath);

                // 2. Удаляем все файлы в Загрузках
                foreach (FileInfo file in di.GetFiles())
                {
                    try
                    {
                        file.Delete();
                    }
                    catch (Exception)
                    {
                        // Файл открыт или занят — просто пропускаем
                        continue;
                    }
                }

                // 3. Удаляем все подпапки в Загрузках
                foreach (DirectoryInfo dir in di.GetDirectories())
                {
                    try
                    {
                        dir.Delete(true);
                    }
                    catch (Exception)
                    {
                        // Папка занята процессом — пропускаем
                        continue;
                    }
                }
            MessageBox.Show("Загрузки очищены", "GenaBesheniy Utility", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            RegistryKey objRegistryKey = Registry.LocalMachine.CreateSubKey(@"Software\Microsoft\Windows\CurrentVersion\Policies\System");
            // Устанавливаем 0, чтобы включить (1 — чтобы выключить)
            objRegistryKey.SetValue("DisableTaskMgr", 0, RegistryValueKind.DWord);
            objRegistryKey.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            RegistryKey objRegistryKey = Registry.LocalMachine.CreateSubKey(@"Software\Microsoft\Windows\CurrentVersion\Policies\System");
            // Устанавливаем 0, чтобы включить (1 — чтобы выключить)
            objRegistryKey.SetValue("DisableCMD", 0, RegistryValueKind.DWord);
            objRegistryKey.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            RegistryKey objRegistryKey = Registry.LocalMachine.CreateSubKey(@"Software\Microsoft\Windows\CurrentVersion\Policies\System");
            // Устанавливаем 0, чтобы включить (1 — чтобы выключить)
            objRegistryKey.SetValue("TurnOffSPIAnimations", 0, RegistryValueKind.DWord);
            objRegistryKey.Close();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Process.Start("shutdown.exe", "/r /f /t 0");
        }

        private void button7_Click(object sender, EventArgs e)
        {
            string prefetchPath = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.Windows),
        "Prefetch");

            try
            {
                // Проверяем существование папки
                if (!Directory.Exists(prefetchPath))
                    return; // Просто выходим если папки нет

                // Очищаем файлы без вывода ошибок
                foreach (string file in Directory.GetFiles(prefetchPath))
                {
                    try
                    {
                        File.Delete(file);
                    }
                    catch
                    {
                        // Игнорируем все ошибки при удалении файлов
                        continue;
                    }
                }

                // Можно добавить очистку подпапок (опционально)
                foreach (string dir in Directory.GetDirectories(prefetchPath))
                {
                    try
                    {
                        Directory.Delete(dir, true);
                    }
                    catch
                    {
                        // Игнорируем ошибки при удалении папок
                    }
                }
            }
            catch
            {
                // Игнорируем все остальные ошибки
            }
            MessageBox.Show("Папка Prefetch очищена", "GenaBesheniy Utility", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
