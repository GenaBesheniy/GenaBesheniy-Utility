﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Configuration;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Linq;
using System.Xml.XmlConfiguration;
using System.Management;

namespace GenaBesheniy_Utility
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            button1.FlatStyle = FlatStyle.Flat;
            button1.FlatAppearance.BorderSize = 0;
            button1.TabStop = false;
            button1.BackColor = Color.FromArgb(225, 225, 225);

            button2.FlatStyle = FlatStyle.Flat;
            button2.FlatAppearance.BorderSize = 0;
            button2.TabStop = false;
            button2.BackColor = Color.FromArgb(225, 225, 225);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string username = System.Windows.Forms.SystemInformation.UserName; // Переменная username
            Directory.Delete(@"C:\Users\" + username + @"\AppData\Local\Temp\", true); // Удаление содержимого temp
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string username = System.Windows.Forms.SystemInformation.UserName; // Переменная username
            Directory.Delete(@"C:\Users\" + username + @"\Downloads\", true); // Удаление содержимого downloads
        }
    }
}
