﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Management;

namespace GenaBesheniy_Utility
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            Load += Form2_Load;
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            string ram = GetTotalRam();
            string disk = GetDiskSize();
            string diskType = GetDiskType();

            labelInfo.Text =
                "Оперативная память\n" +
                $"Объем оперативной памяти: {ram}\n\n" +

                "Материнская плата\n" +
                $"Версия BIOS: {GetBiosVersion()}\n" +
                $"Материнская плата: {GetMotherboard()}\n\n" +

                "Видеокарта\n" +
                $"Видеокарта: {GetGpu()}\n" +
                $"Видеоадаптер: {GetVideoAdapter()}\n\n" +

                "Диск\n" +
                $"Объем накопителя: {disk}\n" +
                $"Тип накопителя: {diskType}\n\n" +

                $"Общая оценка: {GetSystemScore()}\n" +
                $"Имейте ввиду, что характеристика и оценка компьютера может содержать ошибки!";
        }
        // ОЗУ
        string GetTotalRam()
        {
            ulong total = 0;
            var searcher = new ManagementObjectSearcher(
                "SELECT Capacity FROM Win32_PhysicalMemory");

            foreach (ManagementObject obj in searcher.Get())
                total += (ulong)obj["Capacity"];

            return Math.Round(total / 1024.0 / 1024 / 1024, 1) + " ГБ";
        }
        // Диск (накопитель)
        string GetDiskSize()
        {
            ulong size = 0;
            var searcher = new ManagementObjectSearcher(
                "SELECT Size FROM Win32_LogicalDisk WHERE DriveType=3");

            foreach (ManagementObject obj in searcher.Get())
                size += (ulong)obj["Size"];

            return Math.Round(size / 1024.0 / 1024 / 1024, 1) + " ГБ";
        }
        // Тип диска
        string GetDiskType()
        {
            var searcher = new ManagementObjectSearcher(
                "SELECT MediaType FROM Win32_DiskDrive");

            foreach (ManagementObject obj in searcher.Get())
            {
                string media = obj["MediaType"]?.ToString() ?? "";
                if (media.ToLower().Contains("ssd")) return "SSD";
            }
            return "HDD";
        }
        // Версия прошивки BIOS/UEFI
        string GetBiosVersion()
        {
            var searcher = new ManagementObjectSearcher(
                "SELECT SMBIOSBIOSVersion FROM Win32_BIOS");

            foreach (ManagementObject obj in searcher.Get())
                return obj["SMBIOSBIOSVersion"]?.ToString();

            return "—";
        }
        // Материнская плата
        string GetMotherboard()
        {
            var searcher = new ManagementObjectSearcher(
                "SELECT Manufacturer, Product FROM Win32_BaseBoard");

            foreach (ManagementObject obj in searcher.Get())
                return obj["Manufacturer"] + " " + obj["Product"];

            return "—";
        }
        // Видеокарта
        string GetGpu()
        {
            var searcher = new ManagementObjectSearcher(
                "SELECT Name FROM Win32_VideoController");

            foreach (ManagementObject obj in searcher.Get())
                return obj["Name"]?.ToString();

            return "—";
        }
        // Видеоадаптер
        string GetVideoAdapter()
        {
            var searcher = new ManagementObjectSearcher(
                "SELECT Description FROM Win32_VideoController");

            foreach (ManagementObject obj in searcher.Get())
                return obj["Description"]?.ToString();

            return "—";
        }
        // Оценка системы
        private int GetSystemScore()
        {
            int score = 0;

            // CPU
            score += Environment.ProcessorCount * 100;

            // RAM
            ulong ramBytes = 0;
            var ramSearch = new ManagementObjectSearcher(
                "SELECT Capacity FROM Win32_PhysicalMemory");

            foreach (ManagementObject obj in ramSearch.Get())
                ramBytes += (ulong)obj["Capacity"];

            score += (int)(ramBytes / 1024 / 1024 / 1024) * 150;

            // Disk (SSD бонус)
            var diskSearch = new ManagementObjectSearcher(
                "SELECT MediaType FROM Win32_DiskDrive");

            foreach (ManagementObject obj in diskSearch.Get())
            {
                string media = obj["MediaType"]?.ToString() ?? "";
                score += media.ToLower().Contains("ssd") ? 500 : 200;
                break;
            }

            return score;
        }

    }
}
