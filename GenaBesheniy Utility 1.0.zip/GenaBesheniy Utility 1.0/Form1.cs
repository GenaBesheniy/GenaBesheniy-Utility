﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Text;
using System.IO;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Linq;

namespace GenaBesheniy_Utility
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            BtnStyle(this);
        }
        private void BtnStyle(Control parent)
        {
            foreach (Control c in parent.Controls)
            {
                if (c is Button btn && btn.Tag?.ToString() == "btn")
                {
                    btn.FlatStyle = FlatStyle.Flat;
                    btn.FlatAppearance.BorderSize = 0;
                    btn.BackColor = Color.FromArgb(125, 125, 125);
                    btn.TabStop = false;
                    btn.FlatAppearance.BorderSize = 0;
                }

                if (c.HasChildren)
                    BtnStyle(c);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string tempPath = Path.GetTempPath();

            DirectoryInfo di = new DirectoryInfo(tempPath);

            // 2. Удаляем файлы
            foreach (FileInfo file in di.GetFiles())
            {
                try
                {
                    file.Delete();
                }
                catch (Exception)
                {
                    // Если файл занят, просто идем к следующему
                    continue;
                }
            }

            // 3. Удаляем подпапки
            foreach (DirectoryInfo dir in di.GetDirectories())
            {
                try
                {
                    dir.Delete(true);
                }
                catch (Exception)
                {
                    // Если папка занята, пропускаем её
                    continue;
                }
            }
            MessageBox.Show("Папка Temp очищена", "GenaBesheniy Utility", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // 1. Получаем путь к папке Загрузки более надежным способом
            string downloadsPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads");

            if (Directory.Exists(downloadsPath))
            {
                DirectoryInfo di = new DirectoryInfo(downloadsPath);

                // 2. Удаляем все файлы в Загрузках
                foreach (FileInfo file in di.GetFiles())
                {
                    try
                    {
                        file.Delete();
                    }
                    catch (Exception)
                    {
                        // Файл открыт или занят — просто пропускаем
                        continue;
                    }
                }

                // 3. Удаляем все подпапки в Загрузках
                foreach (DirectoryInfo dir in di.GetDirectories())
                {
                    try
                    {
                        dir.Delete(true);
                    }
                    catch (Exception)
                    {
                        // Папка занята процессом — пропускаем
                        continue;
                    }
                }
                MessageBox.Show("Загрузки очищены", "GenaBesheniy Utility", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string prefetchPath = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.Windows),
        "Prefetch");

            try
            {
                // Проверяем существование папки
                if (!Directory.Exists(prefetchPath))
                    return; // Просто выходим если папки нет

                // Очищаем файлы без вывода ошибок
                foreach (string file in Directory.GetFiles(prefetchPath))
                {
                    try
                    {
                        File.Delete(file);
                    }
                    catch
                    {
                        // Игнорируем все ошибки при удалении файлов
                        continue;
                    }
                }

                // Можно добавить очистку подпапок (опционально)
                foreach (string dir in Directory.GetDirectories(prefetchPath))
                {
                    try
                    {
                        Directory.Delete(dir, true);
                    }
                    catch
                    {
                        // Игнорируем ошибки при удалении папок
                    }
                }
            }
            catch
            {
                // Игнорируем все остальные ошибки
            }
            MessageBox.Show("Папка Prefetch очищена", "GenaBesheniy Utility", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Process.Start("ipconfig", "/flushdns");

            MessageBox.Show("DNS очищен!", "GenaBesheniy Utility", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string commands = "/c net stop wuauserv & net stop bits & rd /s /q C:\\Windows\\SoftwareDistribution\\Download & mkdir C:\\Windows\\SoftwareDistribution\\Download & net start bits & net start wuauserv";

            ProcessStartInfo psi = new ProcessStartInfo("cmd.exe", commands)
            {
                Verb = "runas", // ОБЯЗАТЕЛЬНО: запуск от имени администратора
                WindowStyle = ProcessWindowStyle.Hidden,
                UseShellExecute = true
            };

            try
            {
                Process.Start(psi);
                MessageBox.Show("Очистка запущена! Подождите 5-10 секунд.", "Готово");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message);
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            string commands = "/c for /F \"tokens=*\" %1 in ('wevtutil.exe el') DO wevtutil.exe cl \"%1\"";

            ProcessStartInfo psi = new ProcessStartInfo("cmd.exe", commands)
            {
                Verb = "runas",          // Обязательно: права администратора
                WindowStyle = ProcessWindowStyle.Hidden,  // Скрыть черное окно
                UseShellExecute = true
            };

            try
            {
                Process.Start(psi);
                MessageBox.Show("Все системные логи очищены!", "GenaBesheniy Utility", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch
            {
                MessageBox.Show("Ошибка: Не удалось получить права администратора.", "GenaBesheniy Utility", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Form2 f = new Form2();
            f.Show();
        }
    }
}
